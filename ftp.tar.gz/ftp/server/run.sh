./bin/server_noverify ./conf/server.conf
